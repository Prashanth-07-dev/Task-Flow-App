import mongoose from "mongoose";

const Data = mongoose.models.Data
export default Data;