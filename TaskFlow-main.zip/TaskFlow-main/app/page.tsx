import LandingPage from "@/components/Home/LandingPage";

export default function Home() {
  return (
    <>
      <LandingPage />
    </>
  );
}
