export const baseGreenColor = "#16A34A";
export const baseBlueColor = "blue-600";
export const baseRedColor = "red-500";

export const baseBlueBackground = "bg-blue-600";
export const baseRedText = "text-red-500";