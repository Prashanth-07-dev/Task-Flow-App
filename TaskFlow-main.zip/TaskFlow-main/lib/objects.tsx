export const EmptyUserObject = {
    _id: "",
    name: "",
    email: "",
    password: "",
    createdAt: new Date(),
    updatedAt: new Date(),
  }