// export { auth as middleware } from "@/auth"
export default function () {
}